<?php

$sname= 'localhost';
$unmae= 'gwadtiil_customer';
$password = 'customerform@';
$db_name = 'gwadtiil_form';

$conn = mysqli_connect($sname, $unmae, $password, $db_name);

if (!$conn) {
	echo "Connection failed!";
}